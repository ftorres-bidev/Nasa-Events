# Earth Events & Earthquakes ETL (bronze layer)

Python + SQL Server project that loads:

- **NASA EONET events** (`https://eonet.gsfc.nasa.gov/api/v3/events/geojson`) into `dbo.events`
- **USGS earthquakes** (GeoJSON summary feeds) into `dbo.bronze_earthquakes`
- A shared **places** table (`dbo.bronze_places`) that both datasets link to via `PlaceID`

Environment: Windows, SQL Server 2019 (`localhost`, database `NasaEvents`), VS Code, SSMS.

## Project structure

```
sql/      table and view definitions (run in numeric order)
python/   connection helper and loaders
```

## Setup

Use Python 3.12 or 3.13 (3.15 is too new: some packages have no prebuilt wheels).

```
py -3.12 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Create the `NasaEvents` database, then run the scripts in `sql/` in order:

1. `01_create_bronze_places.sql`
2. `02_create_bronze_categories.sql`
3. `03_create_events.sql`
4. `04_create_bronze_earthquakes.sql`
5. `05_create_silver_earthquakes_view.sql`

Check the ODBC driver name in `python/db.py` matches `pyodbc.drivers()`.

## Load earthquakes

```
cd python
python load_quakes.py
```

Loads the last 30 days (`all_month` feed), earthquakes only, skipping IDs already in the table.

## Design notes

- EONET rows are points on an event's track, so the primary key is `(ID, EventDate)`.
- EONET dates are timezone-aware UTC: strip with `dt.tz_localize(None)` before loading.
- EONET geometries can be Points or Polygons; keep Points or compute a centroid for Polygons.
- Create tables yourself with explicit types and load with `if_exists="append"`. pandas would create `EventDate` as SQL Server `TIMESTAMP` (a row-version counter) and default text to `VARCHAR(max)`.
- USGS `time` / `updated` are stored raw (epoch ms, `BIGINT`) in bronze and converted in `dbo.silver_earthquakes`.
- USGS revises events, so a refresh strategy (truncate and reload, or stage + MERGE) is still to be decided.
- `reverse_geocoder` returns the nearest GeoNames city, not a boundary match. For better accuracy use point-in-polygon with the Natural Earth Admin 1 shapefile via geopandas.

## Not yet built

- EONET loader script
- Combined geocoding and places load (fills `PlaceID` on both datasets)
- Refresh strategy (merge/upsert)
- Dashboard (Streamlit + Plotly, Power BI, or static HTML from CSV exports)
