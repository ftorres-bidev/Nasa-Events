USE NasaEvents;
GO

-- NASA EONET events. Each row is one point on an event's track, so ID is not
-- unique on its own: the primary key is (ID, EventDate).
-- NOTE: EventDate must be DATETIME2. SQL Server TIMESTAMP is a row-version
-- counter, not a date. Always load with if_exists="append", never "replace".
IF OBJECT_ID('dbo.events', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.events (
        ID             NVARCHAR(50)  NOT NULL,
        Title          NVARCHAR(500) NULL,
        Status         NVARCHAR(50)  NULL,      -- holds properties.closed (a close date); consider renaming to ClosedDate DATETIME2
        EventDate      DATETIME2     NOT NULL,
        MagnitudeValue FLOAT         NULL,
        MagnitudeUnit  NVARCHAR(50)  NULL,
        GeometryType   NVARCHAR(50)  NULL,
        categoryId     NVARCHAR(50)  NULL,
        Lon            FLOAT         NULL,
        Lat            FLOAT         NULL,
        PlaceID        INT           NULL,
        CONSTRAINT PK_events PRIMARY KEY (ID, EventDate)
    );
END
GO

-- Link to places (only if dbo.bronze_places exists)
IF OBJECT_ID('dbo.bronze_places', 'U') IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_events_places')
BEGIN
    ALTER TABLE dbo.events
        ADD CONSTRAINT FK_events_places
        FOREIGN KEY (PlaceID) REFERENCES dbo.bronze_places(PlaceID);
END
GO
