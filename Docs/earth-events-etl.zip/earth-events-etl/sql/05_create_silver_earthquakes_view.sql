USE NasaEvents;
GO

-- Converts raw USGS epoch milliseconds (BIGINT) to UTC datetimes.
-- Two-step DATEADD because DATEADD only accepts an INT amount.
CREATE OR ALTER VIEW dbo.silver_earthquakes
AS
SELECT
    ID,
    Magnitude,
    MagType,
    Place,
    DATEADD(MILLISECOND, EventTime % 1000,
        DATEADD(SECOND, EventTime / 1000, CAST('1970-01-01' AS DATETIME2(3)))) AS EventTimeUtc,
    DATEADD(MILLISECOND, UpdatedTime % 1000,
        DATEADD(SECOND, UpdatedTime / 1000, CAST('1970-01-01' AS DATETIME2(3)))) AS UpdatedTimeUtc,
    Felt, Cdi, Mmi, Alert, Tsunami, Sig, Nst, Dmin, Rms, Gap,
    EventType, Lon, Lat, DepthKm, PlaceID, LoadedAt
FROM dbo.bronze_earthquakes;
GO
