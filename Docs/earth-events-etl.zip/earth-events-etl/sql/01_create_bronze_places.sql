USE NasaEvents;
GO

-- Shared places table: events and earthquakes both link here via PlaceID
IF OBJECT_ID('dbo.bronze_places', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bronze_places (
        PlaceID     INT IDENTITY(1,1) NOT NULL,
        PlaceName   NVARCHAR(200) NOT NULL,
        State       NVARCHAR(100) NOT NULL DEFAULT '',
        CountryCode NCHAR(2)      NOT NULL,
        Country     NVARCHAR(100) NULL,
        Lat         FLOAT         NULL,
        Lon         FLOAT         NULL,
        CONSTRAINT PK_bronze_places PRIMARY KEY (PlaceID),
        CONSTRAINT UQ_bronze_places UNIQUE (PlaceName, State, CountryCode)
    );
END
GO
