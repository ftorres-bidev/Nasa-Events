USE NasaEvents;
GO

-- EONET category lookup
IF OBJECT_ID('dbo.bronze_categories', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bronze_categories (
        CategoryID  NVARCHAR(50)  NOT NULL,
        Description NVARCHAR(200) NULL,
        CONSTRAINT PK_bronze_categories PRIMARY KEY (CategoryID)
    );
END
GO
