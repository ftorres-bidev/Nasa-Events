USE NasaEvents;
GO

-- Table (safe to re-run; does not drop existing data)
IF OBJECT_ID('dbo.bronze_earthquakes', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bronze_earthquakes (
        ID          NVARCHAR(50)  NOT NULL,   -- USGS feature id, e.g. us7000abcd
        Magnitude   FLOAT         NULL,
        MagType     NVARCHAR(20)  NULL,       -- ml, mb, mw, md ...
        Place       NVARCHAR(300) NULL,       -- text like "10 km SW of Ridgecrest, CA"
        EventTime   BIGINT        NOT NULL,   -- raw USGS time: ms since 1970-01-01 UTC
        UpdatedTime BIGINT        NULL,       -- raw USGS updated: ms since 1970-01-01 UTC
        Felt        INT           NULL,       -- number of felt reports
        Cdi         FLOAT         NULL,       -- community decimal intensity
        Mmi         FLOAT         NULL,       -- instrumental intensity
        Alert       NVARCHAR(20)  NULL,       -- green / yellow / orange / red
        Tsunami     TINYINT       NOT NULL,   -- 0 or 1
        Sig         INT           NULL,       -- significance score
        Nst         INT           NULL,       -- number of stations used
        Dmin        FLOAT         NULL,
        Rms         FLOAT         NULL,
        Gap         FLOAT         NULL,
        EventType   NVARCHAR(50)  NULL,       -- earthquake, quarry blast, ...
        Lon         FLOAT         NOT NULL,
        Lat         FLOAT         NOT NULL,
        DepthKm     FLOAT         NULL,
        PlaceID     INT           NULL,       -- link to dbo.bronze_places
        LoadedAt    DATETIME2(3)  NOT NULL
                    CONSTRAINT DF_bronze_earthquakes_LoadedAt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT PK_bronze_earthquakes PRIMARY KEY (ID)
    );
END
GO

-- Link to places (only if dbo.bronze_places already exists)
IF OBJECT_ID('dbo.bronze_places', 'U') IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_quakes_places')
BEGIN
    ALTER TABLE dbo.bronze_earthquakes
        ADD CONSTRAINT FK_quakes_places
        FOREIGN KEY (PlaceID) REFERENCES dbo.bronze_places(PlaceID);
END
GO

-- Optional index for time-based queries (raw ms value; range filters still work)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_bronze_earthquakes_EventTime')
    CREATE INDEX IX_bronze_earthquakes_EventTime ON dbo.bronze_earthquakes (EventTime);
GO
